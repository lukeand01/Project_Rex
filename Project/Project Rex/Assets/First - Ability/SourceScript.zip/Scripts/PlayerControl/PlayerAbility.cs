using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAbility : MonoBehaviour
{
    //THIS HOLDS TEH ABILITIES. THIS HANDLES THE COOLDOWN.

  



}
